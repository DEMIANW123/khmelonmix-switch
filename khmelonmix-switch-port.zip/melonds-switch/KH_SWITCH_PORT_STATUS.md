# KHMelonMix para Nintendo Switch — estado del port

Base: [RSDuck/melonDS](https://github.com/RSDuck/melonDS) rama `switch-new`
(release6fix1) + el sistema de plugins de
[KHMelonMix](https://github.com/vitor251093/KHMelonMix) (rama `master`).

## Qué se hizo

El core de KHMelonMix (melonDS 0.9.3, `NDS` como clase) y el core de este
port de Switch (melonDS 0.9.2, `NDS` como namespace global) tienen APIs
distintas. Se escribió una capa de compatibilidad (`src/plugins/KHCompat.h/.cpp`)
que traduce las ~200 llamadas de memoria/archivo/GPU que usa el sistema de
plugins hacia las funciones reales de este core, **sin modificar la lógica
de los plugins en sí** (solo se tocaron 5 líneas de `#include` en todo
`src/plugins/`, para redirigir a los shims).

Todo `src/plugins/*.cpp` (Plugin.cpp, PluginKingdomHeartsDays.cpp,
PluginKingdomHeartsReCoded.cpp, PluginManager.cpp, AudioUtils.cpp,
KingdomHeartsHDCollection.cpp, PluginHarvestMoonDsCute.cpp,
PluginMetroidPrimeHunters.cpp, PluginTemplateLua.cpp) **compila limpio**
contra los headers reales de este core (verificado con `g++ -fsyntax-only`
en un entorno x86_64; ver limitación abajo).

Se agregó `src/frontend/switch/KHIntegration.h/.cpp`, el puente entre el
loop principal (`main.cpp`) y el sistema de plugins — es el equivalente,
para Switch, de lo que `EmuThread.cpp` hace en el frontend Qt original.

## Qué funciona (implementado de verdad, no stub)

- **Carga automática del plugin correcto** al insertar una ROM de Days,
  Re:Coded, Harvest Moon DS Cute o Metroid Prime Hunters.
- **Controles**: mapeo completo del stick izquierdo al menú de comandos,
  Lock On / Switch Target en ZL/ZR/click de stick, apertura del menú de
  configuración nativo con Y. Ver la tabla completa en `KHIntegration.cpp`.
- **Detección de escena de juego** (para adaptaciones de UI dependientes
  del estado — la mayoría de las heurísticas, salvo un par de casos
  puntuales, ver abajo).
- **Todos los parches de memoria específicos de cada juego** (los que
  hacen que la cámara, el HUD y los controles se sientan pensados para
  gamepad en vez de para el stylus original).
- **Rumble básico** vía HD Rumble (usa la API estándar de libnx; si tu
  versión de libnx cambió la firma de `hidInitializeVibrationDevices`,
  es la primera función a revisar si el build falla justo ahí).

## Qué compila pero NO hace nada visible todavía (stub documentado)

Estas dos cosas no son "portar código que ya existe" sino construir un
sistema nuevo — se dejaron con hooks conectados y comentarios explicando
exactamente qué falta, en vez de fingir que funcionan:

1. **Audio/video de reemplazo en HD** (música y cutscenes remasterizadas
   de la colección 1.5+2.5, la carpeta de assets opcional). No hay
   decodificador de archivos de audio/video en este core para Switch.
   Sin esa carpeta opcional — el caso común — el juego usa su música y
   cutscenes nativas de DS normalmente, así que esto no rompe nada.

2. **HUD/overlay visual del plugin** (mira de cámara, anillo del menú de
   comandos). Está escrito en OpenGL real; este port de Switch renderiza
   con **deko3d** y no enlaza OpenGL para nada (`CMakeLists.txt` del
   target switch: `target_link_libraries(... core deko3d nx)`, sin mesa/
   EGL/glad). La lógica del plugin corre bien, pero no llega a dibujarse.
   Ver el comentario largo en `src/plugins/KHGLStub.h` para las dos
   maneras de resolver esto (EGL en paralelo a deko3d, o reescribir los
   shaders en DKSL).

3. Dos heurísticas puntuales de detección de "menú principal" en Days
   dependen de contadores de vértices/polígonos por frame que esta
   versión del core no expone (`GPU3D.NumVertices`/`NumPolygons`). Se
   dejaron en 0 — el resto de la detección de escena no se ve afectado.

## Limitación de esta validación

Todo se verificó con `g++ -fsyntax-only` contra los headers reales de
este core, en una máquina x86_64 — **no** con el compilador ARM64 de
devkitA64 ni contra `libnx`/`switch.h` (no están disponibles en este
entorno). Es una validación real y fuerte de que la lógica y los tipos
encajan, pero no reemplaza una compilación completa con tu toolchain.
Es posible que aparezcan uno o dos errores puntuales específicos de
ARM64/libnx al compilar de verdad — probablemente pequeños, dado lo que
ya se validó.

## Cómo compilar

1. Instala [devkitPro](https://devkitpro.org/wiki/Getting_Started) con
   el paquete `switch-dev` (trae devkitA64 + libnx).
2. Instala además: `switch-glm switch-sdl2 deko3d switch-mesa` (revisa
   `BUILD.md` del propio repo de RSDuck si alguno falta).
3. Desde la raíz de este proyecto:
   ```
   mkdir build && cd build
   cmake -DCMAKE_TOOLCHAIN_FILE=$DEVKITPRO/cmake/Switch.cmake -DCMAKE_BUILD_TYPE=Release ..
   make -j$(nproc)
   ```
4. El resultado es `melonDS.elf` → el sistema de build genera un `.nro`
   (revisa el `CMakeLists.txt` raíz para el nombre exacto de salida).
5. Copia el `.nro` a `/switch/` en la SD de tu Switch (con Atmosphère u
   otro CFW de homebrew ya instalado — eso corre por tu cuenta).

## Si algo no compila

Pégame el error completo y seguimos ajustando el shim — la enorme
mayoría de lo que puede fallar en este punto son detalles puntuales de
libnx (firmas de función que cambiaron de versión, algún include que
falta), no problemas de fondo con el diseño del port.
