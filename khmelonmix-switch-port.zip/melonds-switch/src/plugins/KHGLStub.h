// KHGLStub.h
//
// Este build de Switch (RSDuck/melonDS switch-new) renderiza con deko3d,
// no con OpenGL — su CMakeLists no enlaza mesa/EGL/glad para nada (ver
// src/frontend/switch/CMakeLists.txt: solo linkea contra "core deko3d nx").
// El sistema de shapes/HUD de los plugins de KH (buildShapes(), los
// shaders en Plugin_GPU_OpenGL_shaders.h) está escrito contra OpenGL de
// verdad vía OpenGLSupport.h + PlatformOGL.h + glad.
//
// Este archivo sustituye a esa cadena por una versión mínima que solo
// deja compilar el código (mismos nombres de función, mismos tipos),
// pero cuyas implementaciones no hacen nada. Efecto práctico: el plugin
// sigue calculando qué formas dibujar (renderer_composition(), etc.) y
// esa lógica corre bien, pero nada de eso llega a la pantalla.
//
// Para que el HUD/overlay de KH se vea de verdad en Switch hacen falta
// una de estas dos cosas (trabajo real, no hecho en este pase):
//   a) Levantar un contexto EGL/OpenGL ES real en paralelo al de deko3d
//      (vía switch-mesa) y compositar su salida sobre el framebuffer que
//      ya arma Gfx::, o
//   b) Reescribir buildShapes() y los shaders asociados directamente en
//      deko3d (su propio lenguaje de shaders + command buffers), que es
//      la API que este proyecto ya usa para todo lo demás.
//
// La opción (b) es la más consistente con el resto del código y evita
// mezclar dos backends gráficos, pero implica traducir los shaders GLSL
// de Plugin_GPU_OpenGL_shaders.h a DKSL (deko3d shading language) a mano.
#pragma once

#include <cstdint>
#include <cstring>
#include <string>
#include <map>
#include <initializer_list>

using GLuint = uint32_t;
using GLint = int32_t;
using GLenum = uint32_t;
using GLsizeiptr = long;
using GLintptr = long;
using GLboolean = uint8_t;
using GLbitfield = uint32_t;
using GLvoid = void;
using GLfloat = float;
using GLchar = char;

#define GL_ARRAY_BUFFER 0
#define GL_UNIFORM_BUFFER 0
#define GL_STATIC_DRAW 0
#define GL_DYNAMIC_DRAW 0
#define GL_WRITE_ONLY 0

inline void glGenBuffers(GLint, GLuint* out) { if (out) *out = 0; }
inline void glBindBuffer(GLenum, GLuint) {}
inline void glBindBufferBase(GLenum, GLuint, GLuint) {}
inline void glBufferData(GLenum, GLsizeiptr, const void*, GLenum) {}
inline void* glMapBuffer(GLenum, GLenum) { return nullptr; }
inline GLboolean glUnmapBuffer(GLenum) { return 1; }
inline GLint glGetUniformLocation(GLuint, const GLchar*) { return -1; }
inline GLuint glGetUniformBlockIndex(GLuint, const GLchar*) { return 0; }
inline void glUniformBlockBinding(GLuint, GLuint, GLuint) {}
inline void glUniform1f(GLint, GLfloat) {}
inline void glUniform1i(GLint, GLint) {}

namespace melonDS::OpenGL
{

inline void LoadShaderCache() {}
inline void SaveShaderCache() {}

struct AttributeTarget
{
    const char* Name;
    uint32_t Location;
};

inline bool CompileVertexFragmentProgram(GLuint& result,
    const std::string& vs, const std::string& fs,
    const std::string& name,
    const std::initializer_list<AttributeTarget>& vertexInAttrs,
    const std::initializer_list<AttributeTarget>& fragmentOutAttrs)
{
    result = 0;
    return false; // "no se pudo compilar" -> el plugin debe tolerar esto con gracia
}

inline bool CompileComputeProgram(GLuint& result, const std::string& source, const std::string& name)
{
    result = 0;
    return false;
}

}
