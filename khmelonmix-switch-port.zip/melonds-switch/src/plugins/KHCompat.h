// KHCompat.h
//
// Capa de compatibilidad para portar el sistema de plugins de KHMelonMix
// (escrito contra melonDS 0.9.3, con NDS como clase instanciable) sobre
// este core (RSDuck/melonDS switch-new, basado en melonDS 0.9.2, donde
// NDS sigue siendo un namespace global).
//
// Nada de lo que hay en src/plugins/*.cpp fue modificado para esto: este
// archivo solo provee los símbolos que esos archivos esperan encontrar
// (melonDS::NDS, Platform::FileHandle, etc.), reenviando cada llamada a
// la función real de este core.
#pragma once

#include <cstdio>
#include <cstdint>
#include <string>
#include <vector>

#include "../types.h"
#include "../NDS.h"
#include "../NDSCart.h"
#include "../GPU.h"
#include "../Platform.h"

// ---------------------------------------------------------------------
// 1) Acceso a memoria: melonDS::NDS
//    KHMelonMix pasa un puntero melonDS::NDS* entre los plugins. Este
//    core es un singleton global (namespace NDS, no clase), así que el
//    shim no guarda estado propio: cada método reenvía a NDS::Xxx().
// ---------------------------------------------------------------------
namespace melonDS
{

class NDSCartCommon
{
public:
    u8* GetROM() const { return ::NDSCart::CartROM; }
    u32 GetROMLength() const { return ::NDSCart::CartROMSize; }
};

class NDSCartSlotShim
{
public:
    NDSCartCommon* GetCart()
    {
        static NDSCartCommon cart;
        return ::NDSCart::CartROM ? &cart : nullptr;
    }
};

// .Framebuffer[buf][screen].get() -- la API nueva usa un puntero
// inteligente; este core tiene un u32* crudo. Este wrapper solo agrega
// el .get() que el código de los plugins espera encontrar.
class FramebufferSlot
{
public:
    u32* Ptr;
    u32* get() const { return Ptr; }
};

// Stub mínimo de Polygon: nada en este target lo recorre con datos
// reales (ver comentario junto a RenderPolygonRAM más abajo). Existe
// solo para que el código de los plugins que manipula vértices/polígonos
// compile; esa función forma parte del mismo camino de renderer OpenGL
// que no existe en este build de Switch (deko3d).
struct PolygonVertexStub
{
    int32_t FinalColor[4] = {0, 0, 0, 0};
    int32_t Position[4] = {0, 0, 0, 0};
};

struct Polygon
{
    int NumVertices = 0;
    uint32_t Attr = 0;
    uint32_t TexParam = 0;
    PolygonVertexStub* Vertices[10] = {};
};

class GPU2DUnitShim
{
public:
    u16& MasterBrightness;
    u16& BlendCnt;
    u16& BlendAlpha;
};

// nds->GPU.GPU3D.NumVertices / NumPolygons: esta versión del core (0.9.2)
// no lleva un contador agregado de vértices/polígonos por frame (solo
// existe a nivel de cada Polygon individual). Se stubean en 0 -> las
// heurísticas de detección de escena que dependen de estos dos valores
// específicos (ej. "¿esto es el menú principal?") no van a disparar
// correctamente; el resto de la detección de escena sí funciona.
// RenderNumPolygons sí existe tal cual en este core y se conecta real.
// RenderPolygonRAM se deja en nullptr: nada en este target lo recorre
// de verdad, porque es parte del mismo camino de renderer OpenGL que no
// existe aquí (deko3d) -- ver el comentario del Polygon-stub más arriba.
class GPU3DShim
{
public:
    u32 NumVertices = 0;
    u32 NumPolygons = 0;
    u32& RenderNumPolygons;
    Polygon* RenderPolygonRAM[2048] = {};

    GPU3DShim(u32& renderNumPolygons) : RenderNumPolygons(renderNumPolygons) {}
};

class GPUShim
{
public:
    GPU2DUnitShim GPU2D_A{ ::GPU::GPU2D_A.MasterBrightness, ::GPU::GPU2D_A.BlendCnt, ::GPU::GPU2D_A.BlendAlpha };
    GPU2DUnitShim GPU2D_B{ ::GPU::GPU2D_B.MasterBrightness, ::GPU::GPU2D_B.BlendCnt, ::GPU::GPU2D_B.BlendAlpha };
    GPU3DShim GPU3D{ ::GPU3D::RenderNumPolygons };
    int& FrontBuffer{ ::GPU::FrontBuffer };

    // Se refrescan cada vez que se leen (Refresh()), porque los punteros
    // crudos de este core viven en un array C que no podemos referenciar
    // miembro a miembro de forma estática con inicialización agregada.
    FramebufferSlot Framebuffer[2][2];

    GPUShim() { Refresh(); }
    void Refresh()
    {
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++)
                Framebuffer[i][j].Ptr = ::GPU::Framebuffer[i][j];
    }
};

class NDS
{
public:
    NDSCartSlotShim NDSCartSlot;
    GPUShim GPU;
    u16& PowerControl9{ ::NDS::PowerControl9 };

    u8   ARM7Read8(u32 addr)           { return ::NDS::ARM7Read8(addr); }
    u16  ARM7Read16(u32 addr)          { return ::NDS::ARM7Read16(addr); }
    u32  ARM7Read32(u32 addr)          { return ::NDS::ARM7Read32(addr); }
    void ARM7Write8(u32 addr, u8 v)    { ::NDS::ARM7Write8(addr, v); }
    void ARM7Write16(u32 addr, u16 v)  { ::NDS::ARM7Write16(addr, v); }
    void ARM7Write32(u32 addr, u32 v)  { ::NDS::ARM7Write32(addr, v); }

    u8   ARM9Read8(u32 addr)           { return ::NDS::ARM9Read8(addr); }
    u16  ARM9Read16(u32 addr)          { return ::NDS::ARM9Read16(addr); }
    u32  ARM9Read32(u32 addr)          { return ::NDS::ARM9Read32(addr); }
    void ARM9Write8(u32 addr, u8 v)    { ::NDS::ARM9Write8(addr, v); }
    void ARM9Write16(u32 addr, u16 v)  { ::NDS::ARM9Write16(addr, v); }
    void ARM9Write32(u32 addr, u32 v)  { ::NDS::ARM9Write32(addr, v); }

    NDSCartCommon* GetNDSCart()
    {
        static NDSCartCommon cart;
        return ::NDSCart::CartROM ? &cart : nullptr;
    }

    // Este core es un singleton global real, así que una sola instancia
    // del shim (creada una vez) sirve para todo el programa. Los plugins
    // solo guardan un puntero (melonDS::NDS* nds) y llaman métodos sobre
    // él; como el shim no tiene estado propio (todo son referencias a
    // globals reales), no hace falta más que esta única instancia.
    static NDS& Instance()
    {
        static NDS instance;
        return instance;
    }
};

} // namespace melonDS


// ---------------------------------------------------------------------
// 2) Archivos: Platform::FileHandle / FileMode / FileXxx()
//    Este core solo tiene FILE* Platform::OpenFile(path, modeString,
//    mustExist). Los plugins esperan la API con FileHandle opaco y
//    FileMode de bits. Son overloads (firmas distintas), coexisten
//    sin chocar con las funciones reales declaradas en el Platform.h
//    raíz de este proyecto.
// ---------------------------------------------------------------------
namespace Platform
{

enum FileMode : unsigned
{
    None = 0,
    Read = 0b00'00'01,
    Write = 0b00'00'10,
    Preserve = 0b00'01'00,
    NoCreate = 0b00'10'00,
    Text = 0b01'00'00,
    Append = 0b10'00'00,
    ReadWrite = Read | Write,
    ReadWriteExisting = Read | Write | Preserve | NoCreate,
    ReadText = Read | Text,
    WriteText = Write | Text,
};

enum class FileSeekOrigin
{
    Start,
    Current,
    End,
};

struct FileHandle
{
    FILE* File;
};

FileHandle* OpenFile(const std::string& path, FileMode mode);
FileHandle* OpenLocalFile(const std::string& path, FileMode mode);
bool CloseFile(FileHandle* file);
bool IsEndOfFile(FileHandle* file);
bool FileReadLine(char* str, int count, FileHandle* file);
u64 FilePosition(FileHandle* file);
bool FileSeek(FileHandle* file, s64 offset, FileSeekOrigin origin);
void FileRewind(FileHandle* file);
u64 FileRead(void* data, u64 size, u64 count, FileHandle* file);
bool FileFlush(FileHandle* file);
u64 FileWrite(const void* data, u64 size, u64 count, FileHandle* file);
u64 FileWriteFormatted(FileHandle* file, const char* fmt, ...);
u64 FileLength(FileHandle* file);
std::vector<std::string> ContentsOfFolder(const std::string& path, bool includeFolders, bool includeFiles);

} // namespace Platform
