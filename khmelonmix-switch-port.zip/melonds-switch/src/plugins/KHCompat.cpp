// KHCompat.cpp
//
// Ver KHCompat.h para el contexto completo.
#include "KHCompat.h"

#include <cstring>
#include <cstdarg>
#include <dirent.h>
#include <sys/stat.h>

namespace Platform
{

static const char* ModeToString(FileMode mode)
{
    bool read     = mode & Read;
    bool write    = mode & Write;
    bool append   = mode & Append;
    bool preserve = mode & Preserve;

    // Este core no distingue texto/binario a nivel de OS (POSIX/libnx),
    // así que el flag Text no cambia el modo real de apertura.
    if (append)          return "ab";
    if (read && write)   return preserve ? "r+b" : "w+b";
    if (write)           return "wb";
    return "rb"; // Read, o caso por defecto
}

FileHandle* OpenFile(const std::string& path, FileMode mode)
{
    bool mustExist = !(mode & Write) || (mode & NoCreate);
    FILE* f = ::Platform::OpenFile(path.c_str(), ModeToString(mode), mustExist);
    if (!f)
        return nullptr;

    FileHandle* handle = new FileHandle();
    handle->File = f;
    return handle;
}

FileHandle* OpenLocalFile(const std::string& path, FileMode mode)
{
    FILE* f = ::Platform::OpenLocalFile(path.c_str(), ModeToString(mode));
    if (!f)
        return nullptr;

    FileHandle* handle = new FileHandle();
    handle->File = f;
    return handle;
}

bool CloseFile(FileHandle* file)
{
    if (!file) return false;
    bool ok = (fclose(file->File) == 0);
    delete file;
    return ok;
}

bool IsEndOfFile(FileHandle* file)
{
    return file && feof(file->File) != 0;
}

bool FileReadLine(char* str, int count, FileHandle* file)
{
    if (!file) return false;
    return fgets(str, count, file->File) != nullptr;
}

u64 FilePosition(FileHandle* file)
{
    if (!file) return 0;
    return (u64)ftell(file->File);
}

bool FileSeek(FileHandle* file, s64 offset, FileSeekOrigin origin)
{
    if (!file) return false;
    int whence = SEEK_SET;
    if (origin == FileSeekOrigin::Current) whence = SEEK_CUR;
    else if (origin == FileSeekOrigin::End) whence = SEEK_END;
    return fseek(file->File, (long)offset, whence) == 0;
}

void FileRewind(FileHandle* file)
{
    if (file) rewind(file->File);
}

u64 FileRead(void* data, u64 size, u64 count, FileHandle* file)
{
    if (!file) return 0;
    return (u64)fread(data, (size_t)size, (size_t)count, file->File);
}

bool FileFlush(FileHandle* file)
{
    return file && fflush(file->File) == 0;
}

u64 FileWrite(const void* data, u64 size, u64 count, FileHandle* file)
{
    if (!file) return 0;
    return (u64)fwrite(data, (size_t)size, (size_t)count, file->File);
}

u64 FileWriteFormatted(FileHandle* file, const char* fmt, ...)
{
    if (!file) return 0;
    va_list args;
    va_start(args, fmt);
    int ret = vfprintf(file->File, fmt, args);
    va_end(args);
    return ret < 0 ? 0 : (u64)ret;
}

u64 FileLength(FileHandle* file)
{
    if (!file) return 0;
    long pos = ftell(file->File);
    fseek(file->File, 0, SEEK_END);
    long len = ftell(file->File);
    fseek(file->File, pos, SEEK_SET);
    return (u64)len;
}

std::vector<std::string> ContentsOfFolder(const std::string& path, bool includeFolders, bool includeFiles)
{
    std::vector<std::string> result;
    DIR* dir = opendir(path.c_str());
    if (!dir)
        return result;

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr)
    {
        std::string name = entry->d_name;
        if (name == "." || name == "..")
            continue;

        bool isDir = (entry->d_type == DT_DIR);
        if (entry->d_type == DT_UNKNOWN)
        {
            // Algunos filesystems no llenan d_type; confirmamos con stat().
            struct stat st;
            std::string full = path + "/" + name;
            if (stat(full.c_str(), &st) == 0)
                isDir = S_ISDIR(st.st_mode);
        }

        if ((isDir && includeFolders) || (!isDir && includeFiles))
            result.push_back(path + "/" + name);
    }
    closedir(dir);
    return result;
}

} // namespace Platform
