// KHIntegration.h
//
// Puente entre el loop principal de este frontend (src/frontend/switch/main.cpp)
// y el sistema de plugins de KHMelonMix (src/plugins/). Es el equivalente,
// para Switch, de lo que EmuThread.cpp hace en el frontend Qt original:
// cargar el plugin correcto según el gamecode, aplicarle el input de cada
// frame, y reaccionar a lo que el plugin pide (HUD, cámara, pausas de
// cutscene, etc.).
//
// LIMITACIÓN DOCUMENTADA: la reproducción de audio/video de reemplazo en
// alta definición (la colección remasterizada 1.5+2.5, opcional) NO está
// implementada aquí. Ese sistema depende de decodificar archivos de video
// y audio externos, algo que no existe todavía en este core para Switch
// (no hay decodificador de video ni pipeline de audio por archivo, solo el
// SPU emulado de la propia DS). Los hooks correspondientes están
// conectados y compilan, pero se les responde "recurso no disponible", por
// lo que el juego cae automáticamente a su propio contenido de DS nativo
// — exactamente el mismo camino que ya usa cualquier usuario de PC que no
// tenga la carpeta de assets opcional instalada. Todo lo demás (input,
// cámara, HUD, menú de comandos, configuración) sí está implementado.
#pragma once

#include <switch.h>
#include "../../plugins/PluginManager.h"
#include "../../plugins/Plugin.h"

// Definido en main.cpp; lo necesitamos aquí para leer el stick izquierdo
// (menú de comandos) y los botones de las addon keys. Se declara acá en
// vez de en main.h para no añadirle una dependencia de <switch.h> a un
// header que hoy no la tiene.
extern PadState Pad;

namespace KHIntegration
{

// Puntero al plugin activo (nullptr si el juego cargado no tiene uno).
extern Plugins::Plugin* CurrentPlugin;

// Llamar justo después de que una ROM cargó con éxito (en LoadROM(),
// después de poner State = emuState_Running).
void OnROMLoaded();

// Llamar una vez por frame, ANTES de escribir en NDS::SetKeyMask/TouchScreen,
// con el keyMask/touch ya calculados por la lógica normal de main.cpp.
// Los modifica in-place igual que hacía EmuThread.cpp con emuInstance->.
void ApplyPluginInput(u32& keyMask, int& touchX, int& touchY, bool& touching);

// Llamar una vez por frame, INMEDIATAMENTE DESPUÉS de NDS::RunFrame().
void RefreshPluginState();

// Llamar cuando el frame se va a presentar, si se quiere que el plugin
// dibuje su propio HUD/overlay (renderer_composition, etc.) vía OpenGL.
void BuildShapes();

// true mientras el plugin quiera forzar velocidad máxima (transiciones
// de cutscene). Combínalo con el fast-forward que ya calcula main.cpp.
bool ShouldForceFastForward();

// El plugin pidió abrir su pantalla de configuración extendida
// (equivalente a "windowOpenSettings" en Qt). main.cpp debe consultarlo
// tras ApplyPluginInput() y, si es true, mostrar su propio SettingsDialog
// y luego llamar ClearSettingsOverlayRequest().
bool WantsSettingsOverlayOpen();
void ClearSettingsOverlayRequest();

} // namespace KHIntegration
