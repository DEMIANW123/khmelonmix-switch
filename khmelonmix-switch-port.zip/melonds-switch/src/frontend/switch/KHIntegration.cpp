// KHIntegration.cpp
// Ver KHIntegration.h para contexto y limitaciones documentadas.
#include "KHIntegration.h"

#include "../../NDS.h"
#include "../../NDSCart.h"
#include "main.h"

#include <cstdio>

namespace KHIntegration
{

Plugins::Plugin* CurrentPlugin = nullptr;

static bool SettingsOverlayRequested = false;
static u32  LastGameCode = 0;
static bool VibrationInitialized = false;
static HidVibrationDeviceHandle VibrationHandles[2];
static bool CurrentlyRumbling = false;

// ---------------------------------------------------------------------
// Tabla de bindings. El índice real del bit dentro de AddonMask/HotkeyMask
// lo decide el propio plugin (ver customKeyMappingNames en Plugin.h); acá
// solo emparejamos nombre -> botón físico de Switch.
//
// Diseño (ver HOW_TO_PLAY.md del proyecto original para el esquema que
// inspira esto, adaptado para no pisar el mapeo nativo D-Pad/A/B/X/Y/L/R
// que este port de Switch ya tenía funcionando):
//   - Stick izquierdo (direcciones digitales) -> Menú de comandos
//     (el D-Pad físico se deja intacto como D-Pad nativo de la DS)
//   - Click del stick izquierdo -> Lock On
//   - ZL / ZR -> Switch Target Izquierda / Derecha
//   - Menos (-) -> Fullscreen Map Toggle
//   - Y -> Abrir configuración (coincide con la recomendación oficial
//     "Square/X/X/Y" del propio HOW_TO_PLAY.md para mando de Switch)
//   - Jump / AttackInteract / GuardCombo: sin bind propio; A/B/X/Y
//     nativos de la DS ya cubren esas acciones dentro del juego.
// ---------------------------------------------------------------------
struct KeyBinding { const char* name; u64 button; };

static const KeyBinding kAddonBindings[] = {
    { "HK_RLockOn",             HidNpadButton_StickL },
    { "HK_LSwitchTarget",       HidNpadButton_ZL },
    { "HK_RSwitchTarget",       HidNpadButton_ZR },
    { "HK_FullscreenMapToggle", HidNpadButton_Minus },
    { "HK_HUDToggle",           HidNpadButton_StickR }, // mantener pulsado
};

static const KeyBinding kHotkeyBindings[] = {
    { "HK_OpenSettings", HidNpadButton_Y },
};

static void SetBitByName(Plugins::Plugin* plugin, u32* mask, const char* name, bool held)
{
    int idx = plugin->customKeyIndexByName(name);
    if (idx < 0 || idx >= 32)
        return;
    if (held) *mask |= (1u << idx);
    else      *mask &= ~(1u << (u32)idx);
}

static void InitVibrationIfNeeded()
{
    if (VibrationInitialized)
        return;
    // La firma exacta de hidInitializeVibrationDevices puede variar entre
    // versiones de libnx; si tu toolchain se queja de esta línea, revisa
    // la firma actual en switch/hid.h y ajusta la llamada.
    HidVibrationDeviceHandle handles[2];
    Result rc = hidInitializeVibrationDevices(handles, 2, HidNpadIdType_No1,
        (HidNpadStyleTag)(HidNpadStyleTag_NpadHandheld | HidNpadStyleTag_NpadJoyDual));
    if (R_SUCCEEDED(rc))
    {
        VibrationHandles[0] = handles[0];
        VibrationHandles[1] = handles[1];
        VibrationInitialized = true;
    }
}

static void SetRumble(bool on)
{
    InitVibrationIfNeeded();
    if (!VibrationInitialized)
        return;
    if (on == CurrentlyRumbling)
        return;

    HidVibrationValue value{};
    if (on)
    {
        value.amp_low = 0.5f;
        value.freq_low = 160.0f;
        value.amp_high = 0.5f;
        value.freq_high = 320.0f;
    }
    else
    {
        value.amp_low = 0.0f;
        value.freq_low = 160.0f;
        value.amp_high = 0.0f;
        value.freq_high = 320.0f;
    }
    hidSendVibrationValue(VibrationHandles[0], &value);
    hidSendVibrationValue(VibrationHandles[1], &value);
    CurrentlyRumbling = on;
}

void OnROMLoaded()
{
    if (!NDSCart::CartROM)
        return;

    u32 gamecode = *(u32*)(NDSCart::CartROM + 0x0C);

    delete CurrentPlugin;
    CurrentPlugin = Plugins::PluginManager::load(gamecode);
    LastGameCode = gamecode;

    if (CurrentPlugin)
    {
        CurrentPlugin->setNds(&melonDS::NDS::Instance());
        CurrentPlugin->onLoadROM();
        printf("[KH] Plugin cargado para gamecode %08X\n", gamecode);
    }
}

void ApplyPluginInput(u32& keyMask, int& touchX, int& touchY, bool& touching)
{
    if (!CurrentPlugin || !CurrentPlugin->isReady())
        return;

    u16 tx = (u16)touchX, ty = (u16)touchY;
    bool touch = touching;

    // --- Menú de comandos: stick izquierdo como direccional digital ---
    padUpdate(&Pad);
    HidAnalogStickState lstick = padGetStickPos(&Pad, 0);
    const s32 threshold = JOYSTICK_MAX / 2;
    u32 addonMask = 0, addonPress = 0;

    SetBitByName(CurrentPlugin, &addonMask, "HK_CommandMenuUp",    lstick.y >  threshold);
    SetBitByName(CurrentPlugin, &addonMask, "HK_CommandMenuDown",  lstick.y < -threshold);
    SetBitByName(CurrentPlugin, &addonMask, "HK_CommandMenuLeft",  lstick.x < -threshold);
    SetBitByName(CurrentPlugin, &addonMask, "HK_CommandMenuRight", lstick.x >  threshold);

    // --- Resto de addon keys fijas ---
    u64 held = padGetButtons(&Pad);
    for (const auto& kb : kAddonBindings)
        SetBitByName(CurrentPlugin, &addonMask, kb.name, held & kb.button);

    addonPress = addonMask; // esta API no distingue press/held por separado a nivel de este puente;
                             // el propio plugin debounce-ea internamente vía sus *_PRESS_FRAME_LIMIT

    u32 hotkeyMask = 0, hotkeyPress = 0;
    for (const auto& kb : kHotkeyBindings)
        SetBitByName(CurrentPlugin, &hotkeyMask, kb.name, held & kb.button);
    hotkeyPress = hotkeyMask;

    CurrentPlugin->applyTouchKeyMaskToTouchControls(&tx, &ty, &touch, 0);
    CurrentPlugin->applyHotkeyToInputMaskOrTouchControls(&keyMask, &tx, &ty, &touch, &hotkeyMask, &hotkeyPress);
    CurrentPlugin->applyAddonKeysToInputMaskOrTouchControls(&keyMask, &tx, &ty, &touch, &addonMask, &addonPress);

    touchX = tx;
    touchY = ty;
    touching = touch;

    SetRumble(CurrentPlugin->shouldRumble());

    if (hotkeyMask != 0 && CurrentPlugin->shouldOpenKHExtendedSettings())
        SettingsOverlayRequested = true;
}

void RefreshPluginState()
{
    if (!CurrentPlugin)
        return;

    bool sceneChanged = CurrentPlugin->refreshGameScene();
    (void)sceneChanged; // el port original muestra un OSD con el nombre de la escena; opcional en Switch

    // --- Reemplazo de audio (BGM remasterizado) y video (cutscenes HD) ---
    // No implementado en este pase del port: no existe todavía un pipeline
    // de decodificación de audio/video de archivo en este core para Switch
    // (solo el SPU emulado de la propia DS). Deliberadamente NO se actúa
    // sobre shouldStartBackgroundMusic()/ShouldStartReplacementCutscene():
    // como esas rutas solo se activan cuando el plugin encontró assets
    // opcionales de la colección 1.5+2.5, al no tocarlas el juego cae
    // automáticamente a su música y cutscenes nativas de DS — el mismo
    // camino que ya usa cualquier usuario sin esa carpeta opcional.

    if (CurrentPlugin->ShouldPauseCutsceneEmulation())
        Emulation::State = Emulation::emuState_Paused;

    if (CurrentPlugin->ShouldResumeCutsceneEmulation())
        Emulation::State = Emulation::emuState_Running;

    if (CurrentPlugin->ShouldReturnToGameAfterCutscene())
        Emulation::State = Emulation::emuState_Running;

    if (CurrentPlugin->ShouldUnmuteAfterCutscene())
        Emulation::State = Emulation::emuState_Running;

    if (CurrentPlugin->StoppedIngameCutscene())
        Emulation::State = Emulation::emuState_Paused;
}

void BuildShapes()
{
    if (CurrentPlugin && CurrentPlugin->isReady() && CurrentPlugin->shouldRenderFrame())
        CurrentPlugin->buildShapes();
}

bool ShouldForceFastForward()
{
    if (!CurrentPlugin)
        return false;
    return CurrentPlugin->ShouldTerminateIngameCutscene() && CurrentPlugin->RunningReplacementCutscene();
}

bool WantsSettingsOverlayOpen()
{
    return SettingsOverlayRequested;
}

void ClearSettingsOverlayRequest()
{
    SettingsOverlayRequested = false;
}

} // namespace KHIntegration
